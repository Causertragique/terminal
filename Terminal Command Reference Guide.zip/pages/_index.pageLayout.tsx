import { SharedLayout } from '../components/SharedLayout';

export default [SharedLayout];