import { UserRoute } from '../components/ProtectedRoute';

const layouts = [UserRoute];
export default layouts;