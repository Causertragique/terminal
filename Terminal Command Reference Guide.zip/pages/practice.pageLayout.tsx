import { UserRoute } from '../components/ProtectedRoute';

export default [UserRoute];